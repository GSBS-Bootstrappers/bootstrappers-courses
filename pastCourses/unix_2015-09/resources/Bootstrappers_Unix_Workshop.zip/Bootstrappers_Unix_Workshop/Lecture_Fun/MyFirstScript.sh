#!/bin/bash

a=1
b=1

c=$(($a+$b))

echo $c

wc -l GENCODE*
